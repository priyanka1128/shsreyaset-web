<!----------------include header file----------------------->
<?php
include('connection.php');
include('subadmin_header.php');
@ob_start();
@session_start();
error_reporting(0);
if($_SESSION["username"]==true)
{
 
}
else
{
	 header('location:index.php');
}
?>

<!----------------------sub-navbar--------------------------->
   <div class="breadcrumbs">
        <div class="breadcrumbs-inner">
            <div class="row m-0">
                <div class="col-sm-4">
                    <div class="page-header float-left">
                       
                    </div>
                </div>
                    <div class="col-sm-8">
                        <div class="page-header float-right">
                            <div class="page-title">
                                <ol class="breadcrumb text-right">
                                    <li><a href="#">Dashboard</a></li>
                                        <li><a href="#">Events</a></li>
                                            <li class="active">Show Type</li>
                                </ol>
                            </div>
                        </div>
                    </div>
            </div>
        </div>
    </div>
    
       <div class="content pb-0">
            <div class="row">
                <div class="col-lg-2"></div>
                     <div class="col-lg-8">
                        <div class="card">
                            <div class="card-header">Add Show Type</div>
                                <div class="card-body card-block">
                                    <form action="#" method="post" class="form-horizontal"enctype="multipart/form-data">
                                        <div class="row form-group">
                                            <div class="col col-md-12">
                                        
                           
                                             <div class="row form-group">
                                                <div class="col col-md-6">
                                                    <label for="company" class=" form-control-label">Language</label>
                                                    <input type="time-local" id="postal-code" class="form-control" id="meeting-time"
                                                    name="lang">
                                                </div>
                                                
                                                <div class="col col-md-6">
                                                    <label for="company" class=" form-control-label">Dimentions</label> 
                                                    <input type="time-local" id="postal-code" class="form-control" id="meeting-time"
                                                    name="dimention">
                                                </div>
                                            </div>
                                            
                                           
                                             
                                             

                                                    <center> <button type="submit" name="submit" class="btn btn-danger">Submit</button></center>
                                    </form>
                        </div>
                </div>
            </div>
            
        </div> <!-- .content -->
        <!----------------------end of form---------------------------------------->
    
    
     <?php

       if (isset($_POST['submit'])) {
           
        
        $lang=$_POST['lang'];
        $dimention=$_POST['dimention'];

              
  	$sql_u = "SELECT * FROM show_type  WHERE dimention='$dimention'";
	$res_u =  mysqli_query($db, $sql_u);
  

  	if (mysqli_num_rows($res_u) >0) {
                                            echo "<script>alert(' dimention , already exists........!');
                                            window.location='show_type.php';
                                            </script>";
                                            } 
                                            
                                            
                                            
                                            
                                            
        
else{
          
        
    
       $query="INSERT show_type (dimention)
       VALUES('$dimention'); INSERT language (language)
       VALUES('$lang');" or die(mysqli_error($query));
       mysqli_multi_query($db, $query);
       
        
       
    
      
       
          }
             if($query)
                                                           {
                                            echo "<script>alert('  Show Type added Successfully........!');
                                            window.location='show_type.php';
                                            </script>";
                                            } 
                                            
       }
          ?>

    
    
    
    
    
     <?php
       include('footer.php');
     ?> 