<?php
include_once("db.php");

	$f_name=$_POST['f_name'];
	$l_name=$_POST['l_name'];
	$email=$_POST['email'];
	$mobile=$_POST['mobile'];
	$dob=$_POST['dob'];
	$fan_of=$_POST['fan_of'];
	$gender=$_POST['gender'];
	$pic = $_POST['pic'];
 
    $ImageName = $_POST['mobile'];
    $ImagePath = "uploads/$ImageName.jpg";
 
    $ServerURL = "https://shreyaset.com/Shreyas/shreyasapi/$ImagePath";

	$sql="UPDATE users set f_name='$f_name',l_name='$l_name',email='$email',mobile='$mobile',
	dob='$dob',fan_of='$fan_of',gender='$gender',pic='$ServerURL' WHERE mobile='$mobile'";
	
    $data = array();
	if(mysqli_query($con,$sql)){
	    file_put_contents($ImagePath,base64_decode($pic));
		         $stmt=mysqli_query($con,"select * from users where mobile='$mobile'");
	            $row = mysqli_fetch_array($stmt);
                $f_name=$row['f_name'];
                $l_name=$row['l_name'];
                $dob=$row['dob'];
                $email=$row['email'];
                $mobile=$row['mobile'];
                $gender=$row['gender'];
                $fan_of=$row['fan_of'];
                $lat=$row['latitude'];
                $long=$row['longitude'];
            	$pic=$row['pic'];
                
                 $temp = array(); 
                  $temp["status"] = "Ok";
			     $temp["message"] = "Profile Update Successful"; 
                 $temp['f_name'] = $f_name; 
                 $temp['l_name'] = $l_name;
                 $temp['dob'] = $dob;
                 $temp['email'] = $email;
                 $temp['mobile'] = $mobile;
                 $temp['gender'] = $gender;
                 $temp['fan_of'] = $fan_of;
                 $temp['lat'] = $lat;
                 $temp['long'] = $long;
                 $temp['pic'] = $pic;
       
                 array_push($data, $temp);
			      
                 //displaying the result in json format 
                 echo json_encode($data);
	}
	else{
		        $temp["status"] = "Failed";
		        $temp["message"] = "Failed";
		  
     	        array_push($data, $temp);
     	        echo json_encode($data);
	}
?>