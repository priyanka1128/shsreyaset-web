<?php 
/*
user_id,theater_id,screen_id,seat_no,event_id,seat_category_id,status,qrcode,created_at
*/
include_once("db.php");

$user_name = $_POST['user_name'];
$user_id = $_POST['user_id'];
$user_email = $_POST['user_email'];
$user_theater_id = $_POST['theater_id'];
$user_event_id = $_POST['event_id'];



$str = $user_name.$user_id.$user_email.$user_theater_id ;//$user_user_id.$user_theater_id.$user_screen_id.$user_seat_no.$user_event_id.$user_seat_category_id.$user_status ; 
$qrcode = sha1($str);

echo $qrcode;

$save_qrcode = mysqli_query($con,"INSERT INTO booking (user_id,theater_id,status,current_status,event_id,qrcode) VALUES ('$user_id','$user_theater_id','PENDING','PENDING','$user_event_id','$qrcode')");


?> 