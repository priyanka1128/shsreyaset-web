<?php 
    include_once("db.php");
    
    $qrcode=$_POST['qrcode'];
    
    $isQrCodeAvailable= mysqli_query($con,"SELECT qrcode, user_id FROM booking where qrcode = '$qrcode' and status = 1");
    
    $row = mysqli_fetch_array($isQrCodeAvailable);
    $qr= $row['qrcode'];
    $user_id= $row['user_id'];
    
    if($qr == $qrcode){
        
        $userDetails = mysqli_query($con,"SELECT * FROM users where id = '$user_id' ");
        $row = mysqli_fetch_array($userDetails);
        $user_name= $row['f_name'];
        $user_mobile=$row["mobile"];
        
            $myObj->status = "ok";
            $myObj->message = "success";
            /*$myObj->name = $user_name;
            $myObj->mobile = $user_mobile;*/
            echo json_encode($myObj);
    }else{
            $myObj->status = "Failed";
            $myObj->message = "USER NOT VALID";
            echo json_encode($myObj);
    }
    
    
    

?>