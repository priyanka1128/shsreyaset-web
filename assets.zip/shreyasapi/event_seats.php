<?php 
include_once("db.php");

$user_id = $_POST['user_id'];
$user_theater_id = $_POST['theater_id'];
$user_event_id = $_POST['event_id'];
$user_seat_category_id = $_POST['seat_category_id'];


?> 