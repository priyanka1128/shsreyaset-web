<?php

    include_once("db.php");

   $vip=$_POST['vip'];
        
        $mvp=$_POST['mvp'];
        
            $normal=$_POST['normal'];
             $tname=$_POST['tname'];
               $capacity=$_POST['capacity'];
               $address=$_POST['address'];
               
                $insert = mysqli_query($con, "INSERT INTO theaters (name,capacity,vip,mvp,normal) VALUES('$tname','$capacity','$vip','$mvp','$normal')");
                
                mysqli_query($con,"INSERT INTO address(map_adress) VALUES('$address')");
    
                $theater = mysqli_query($con,"SELECT id FROM theaters WHERE created_date = (SELECT MAX(created_date) FROM theaters)");
                $theater_row = mysqli_fetch_array($theater);
                $th_id = $theater_row['id'];
                echo $th_id ;
                
                $address = mysqli_query($con,"SELECT id FROM address WHERE created_at = (SELECT MAX(created_at) FROM address)");
                $address_row = mysqli_fetch_array($address);
                $ad_id = $address_row['id'];
                echo $ad_id ;
                
                mysqli_query($con,"update theaters set address_id = '$ad_id' WHERE id='$th_id'");
               
                
?>