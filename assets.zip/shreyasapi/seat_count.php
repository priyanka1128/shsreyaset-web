<?php

 include_once("db.php");
  
$event_id = $_POST["event_id"];
$request_theater = mysqli_query($con,"SELECT id FROM theaters where event_id = '$event_id'");
$row_theater = mysqli_fetch_array($request_theater);
$theater_id = $row_theater['id'];

 

 $response = array();
 $request_theater = mysqli_query($con,"SELECT vip,mvp,normal FROM theaters where id = '$theater_id' AND event_id = '$event_id'");
 
 $row = mysqli_fetch_array($request_theater);
 $vip_seat_no = $row['vip'];
 $mvp_seat_no = $row['mvp'];
 $normal_seat_no = $row['normal'];
 
 
 $request_booking_vip_count = mysqli_query($con,"SELECT COUNT(seat_type) as vip_seat_booked FROM booking WHERE theater_id = '$theater_id' AND event_id = '$event_id' AND seat_type = 'vip' ");
 $request_booking_mvp_count = mysqli_query($con,"SELECT COUNT(seat_type) as mvp_seat_booked FROM booking WHERE theater_id = '$theater_id' AND event_id = '$event_id' AND seat_type = 'mvp' ");
 $request_booking_normal_count = mysqli_query($con,"SELECT COUNT(seat_type) as normal_seat_booked FROM booking WHERE theater_id = '$theater_id' AND event_id = '$event_id' AND seat_type = 'normal' ");

 $vip_seat_booked = mysqli_fetch_array($request_booking_vip_count);
 $mvp_seat_booked = mysqli_fetch_array($request_booking_mvp_count);
 $normal_seat_booked = mysqli_fetch_array($request_booking_normal_count);

 
 $vip_seat_remaining = (int)$vip_seat_no - (int)$vip_seat_booked['vip_seat_booked'];
 $mvp_seat_remaining = (int)$mvp_seat_no - (int)$mvp_seat_booked['mvp_seat_booked'];
 $normal_seat_remaining = (int)$normal_seat_no - (int)$normal_seat_booked['normal_seat_booked'];
 
 $temp['vip_total_seat'] = $vip_seat_no;
 $temp['mvp_total_seat'] = $mvp_seat_no;
 $temp['normal_total_seat'] = $normal_seat_no;
 
 $temp['vip_seat_booked'] = $vip_seat_booked['vip_seat_booked'];
 $temp['mvp_seat_booked'] = $mvp_seat_booked['mvp_seat_booked'];
 $temp['normal_seat_booked'] = $normal_seat_booked['normal_seat_booked'];

 $temp['vip_seat_remaining'] = $vip_seat_remaining;
 $temp['mvp_seat_remaining'] = $mvp_seat_remaining;
 $temp['normal_seat_remaining'] = $normal_seat_remaining;
 
         $myObj->status = "ok";
         $myObj->message = "success";
         $myObj->vip_seat_remaining=$vip_seat_remaining;
         $myObj->mvp_seat_remaining=$mvp_seat_remaining;
         $myObj->normal_seat_remaining=$normal_seat_remaining;
         echo json_encode($myObj);
 
 /*array_push($response,$temp);
 
 echo json_encode($response);*/

?>