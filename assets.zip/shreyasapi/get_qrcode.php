<?php

include_once("db.php");

$mobile = $_POST['mobile'];
$users = mysqli_query($con,"SELECT id FROM users where CONCAT('+91',mobile)='$mobile' OR mobile='$mobile' OR mobile=CONCAT('91','$mobile') ");
$row = mysqli_fetch_array($users);
$user_id = $row['id'];
$response = array();
$request_booking = mysqli_query($con,"SELECT * FROM booking where user_id = '$user_id'");
 while($row_booking = mysqli_fetch_array($request_booking)){
    $status = $row_booking['status'];
    if($status==1){
        
        $theater_id = $row_booking['theater_id'];
        $event_id = $row_booking['event_id'];
        $qrcode = $row_booking['qrcode'];
            
        $request_theater = mysqli_query($con,"SELECT * FROM theaters where id = $theater_id");
        while($row_theater = mysqli_fetch_array($request_theater)){
            $theater_name = $row_theater['name'];
            $theater_event_time = $row_theater['event_time'];
            $theater_event_date = $row_theater['event_date'];
        }

        $request_event = mysqli_query($con,"SELECT * FROM events where id = $event_id");
        while($row_events = mysqli_fetch_array($request_event)){
            $event_name = $row_events['name'];
            $poster =$row_events['poster'];
        }
        
        $temp['event_name'] = $event_name;
        $temp['event_time'] = $theater_event_time;
        $temp['event_date'] = $theater_event_date;
        $temp['theater_name'] = $theater_name;
        $temp['qrcode'] = $qrcode;
        $temp['screen']="None";
        $temp['seat_no']="None";
        $temp['number_of_ticket']="1 Ticket";
        $temp['poster']=$poster;
        $temp['status']="SUCCESS";
        
        array_push($response,$temp);
      
    }
    elseif(strcasecmp($status,"PENDING")==0){
       
        $theater_id = $row_booking['theater_id'];
        $event_id = $row_booking['event_id'];
        $qrcode = $row_booking['qrcode'];
            
        $request_theater = mysqli_query($con,"SELECT * FROM theaters where id = $theater_id");
        while($row_theater = mysqli_fetch_array($request_theater)){
            $theater_name = $row_theater['name'];
            $theater_event_time = $row_theater['event_time'];
            $theater_event_date = $row_theater['event_date'];
        }
        
    
    
        $request_event = mysqli_query($con,"SELECT * FROM events where id = $event_id");
        while($row_events = mysqli_fetch_array($request_event)){
            $event_name = $row_events['name'];
            $poster =$row_events['poster'];
        }
        
        $temp['event_name'] = $event_name;
        $temp['event_time'] = $theater_event_time;
        $temp['event_date'] = $theater_event_date;
        $temp['theater_name'] = $theater_name;
        $temp['qrcode'] = "None";
        $temp['screen']="None";
        $temp['seat_no']="None";
        $temp['number_of_ticket']="1 Ticket";
        $temp['poster']=$poster;
        $temp['status']="PENDING";
        
        array_push($response,$temp);
    }
        
    else{
       
        $theater_id = $row_booking['theater_id'];
        $event_id = $row_booking['event_id'];
        $qrcode = $row_booking['qrcode'];
            
        $request_theater = mysqli_query($con,"SELECT * FROM theaters where id = $theater_id");
        while($row_theater = mysqli_fetch_array($request_theater)){
            $theater_name = $row_theater['name'];
            $theater_event_time = $row_theater['event_time'];
            $theater_event_date = $row_theater['event_date'];
        }
    
        $request_event = mysqli_query($con,"SELECT * FROM events where id = $event_id");
        while($row_events = mysqli_fetch_array($request_event)){
            $event_name = $row_events['name'];
            $poster =$row_events['poster'];
        }
        
        $temp['event_name'] = $event_name;
        $temp['event_time'] = $theater_event_time;
        $temp['event_date'] = $theater_event_date;
        $temp['theater_name'] = $theater_name;
        $temp['qrcode'] = "None";
        $temp['screen']="None";
        $temp['seat_no']="None";
        $temp['number_of_ticket']="none";
        $temp['poster']=$poster;
        $temp['status']="REJECTED";
            
        array_push($response,$temp);
    }
     
}
    echo json_encode($response);
?>