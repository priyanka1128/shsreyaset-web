<?php

include_once("db.php");

$event_id = $_POST['id'];
$event_type = strtolower($_POST['type']);

$retreval = mysqli_query($con,"SELECT * FROM events where id = '$event_id' and lower(type) = '$event_type' and status =0 ");

$myObj;

  $row = mysqli_fetch_array($retreval);
    
    $event_duration = $row['duration'];
    $event_release_date = $row['release_date'];
    $event_starcast = $row['starcast'];
    $event_banner = $row['banner'];
    $event_videolink = $row['videolink'];
    $event_language = $row['language'];
    $event_dimentions = $row['dimentions'];
    $event_description = $row['description'];
    $event_genre=$row['genre'];
    $event_name=$row['name'];
 
    

        $myObj->status = "Ok";
        $myObj->message = "suceess";
        // $myObj->data = $temp;
        $myObj->duration= $event_duration;
        $myObj->release_date=$event_release_date;
        $myObj->starcast=$event_starcast;
        $myObj->language=$event_language;
        $myObj->dimentions=$event_dimentions;
        $myObj->description=$event_description;
        $myObj->genre=$event_genre;
        $myObj->poster= $event_banner;
        $myObj->videolink = $event_videolink;
        $myObj->event_name=$event_name;
        
        
        echo json_encode($myObj);
?>