<?php

    include_once("db.php");
    
   
    $search_text = $_POST['search_text'];
     
    $search_request = mysqli_query($con,"SELECT id,poster,name,type,language FROM events WHERE name LIKE '%$search_text%' OR genre LIKE '$search_text%' OR starcast LIKE '%$search_text%'");
    
    $response = array();
    
    while($search_row = mysqli_fetch_array($search_request)){
        $event_id = $search_row['id'];
        $event_poster = $search_row['poster'];
        $event_name = $search_row['name'];
        $event_type = $search_row['type'];
        $event_language = $search_row['language'];
        
        $temp['id']=$event_id;
        $temp['type']=$event_type;
        $temp['name']=$event_name;
        $temp['poster']=$event_poster;
        $temp['language']=$event_language;
        
        array_push($response, $temp);
        
    }
    
    $myObj->status = "Ok";
    $myObj->message = "suceess";
    $myObj->data = $response;
    echo json_encode($myObj);
    //1echo json_encode(array($temp1,$response));

?>