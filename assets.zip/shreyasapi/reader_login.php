<?php
include_once("db.php");

	$mobile=$_POST['mobile'];
	$password=$_POST['password'];
	$isuserExists=mysqli_query($con,"select * from admin where CONCAT('+91',mobile)='$mobile' OR mobile='$mobile' OR mobile=CONCAT('91','$mobile') ");
	$row=mysqli_fetch_array($isuserExists);
	$mobile1=$row['mobile'];
	$mobile2="+91";
    $password1 =$row['password'];
    $first_name=$row['first_name'];
    $last_name=$row['last_name'];
    $email=$row['email'];
    $mobile=$row['mobile'];


	if ($mobile == $mobile2.$mobile1 || $mobile = $mobile1  && $password == $password1) {
	  
                $myObj->status = "ok";
                $myObj->message = "success";
                $myObj->first_Name =$first_name;
                $myObj->last_Name = $last_name;
                $myObj->email = $email;
                $myObj->mobile = $mobile;
                $myObj->password = $password1;
     	        echo json_encode($myObj);
            
	}else{
	            $myObj->status = "Failed";
                $myObj->message = "User Doesn't Exists";
     	        echo json_encode($myObj);
	}
?>