<?php

include_once("db.php");

$theater_id = $_POST['theater_id'];
//$screen_id = $_POST['screen_id'];



$request_seat_layout = mysqli_query($con,"SELECT vip,mvp,normal FROM theaters where id = '$theater_id'");

$response = array();

$row = mysqli_fetch_array($request_seat_layout);
$vip_layout = $row['vip'];
$mvp_layout = $row['mvp'];
$normal_layout = $row['normal'];

$temp['vip'] = $vip_layout;
$temp['mvp'] = $mvp_layout;
$temp['normal'] = $normal_layout;

/*
$temp['layout'] = $vip_layout.$mvp_layout.$normal_layout;*/


array_push($response,$temp);


echo json_encode($response);
?>