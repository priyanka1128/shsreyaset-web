<?php

    include_once("db.php");
    $type=$_POST['type'];

    if(strcasecmp($type,"All")==0){
           
        $retreval = mysqli_query($con,"SELECT * FROM events");
        $response=array();
           
        while($row = mysqli_fetch_array($retreval)) {
            $event_id=$row['id'];
            $event_type=$row['type'];
            $event_name=$row['name'];
            $event_poster=$row['poster'];
       
       
            $temp['id']=$event_id;
            $temp['type']=$event_type;
            $temp['name']=$event_name;
            $temp['poster']=$event_poster;
            $temp['language']=null;
            
            array_push($response, $temp);
        }
            
        $myObj->status = "Ok";
        $myObj->message = "suceess";
        $myObj->data = $response;
        echo json_encode($myObj);
        //1echo json_encode(array($temp1,$response));
         
    }
    else{
        $retreval = mysqli_query($con,"SELECT * FROM events WHERE type = '$type'");
      //  $data=array(); 
        $response=array();
          
          /*$temp1["status"] = "Ok";
		  $temp1["message"] = "suceess";
		  array_push($data, $temp1);*/
            while($row = mysqli_fetch_array($retreval)) {
            $event_type=$row['type'];
            $event_name=$row['name'];
            $event_poster=$row['banner'];
            $event_language=$row['language'];
            $event_id=$row['id'];
           
            
           
       
           $temp['id']=$event_id;
            $temp['type']=$event_type;
            $temp['name']=$event_name;
            $temp['language']=$event_language;
            $temp['poster']=$event_poster;
          
            array_push($response, $temp);
        }
        
        $myObj->status = "Ok";
        $myObj->message = "suceess";
        $myObj->data = $response;
        echo json_encode($myObj);
        //1echo json_encode(array($temp1,$response));
            
		   
           
    }
    
?>