<?php

include_once("db.php");

$user_mobile = $_POST['mobile'];
$user_event_id = $_POST['event_id'];
$seat_type = $_POST['seat_type'];
$str = $user_mobile.$user_theater_id.$user_event_id ;
        $qrcode = sha1($str);
        
       
 //vip or mip
 $user_secret_code  = $_POST['user_secret_code'];
 
$isUserBookingExists=mysqli_query($con,"select qrcode from booking where qrcode = '$qrcode' ");
$row = mysqli_fetch_array($isUserBookingExists);
$qr = $row['qrcode'];


if($qr != $qrcode){


$request_user = mysqli_query($con,"SELECT id FROM users where CONCAT('+91',mobile)='$user_mobile' OR mobile='$user_mobile' OR mobile=CONCAT('91','$user_mobile')");
$row = mysqli_fetch_array($request_user);
$user_id=$row['id'];



$request_theater = mysqli_query($con,"SELECT theater_id FROM event_theatre where event_id = '$user_event_id'");
$row_theater = mysqli_fetch_array($request_theater);
$user_theater_id = $row_theater['theater_id'];


if(strcasecmp($seat_type,'vip') == 0){
   
    $request_secret_code = mysqli_query($con,"SELECT code FROM secret_code where mobile = '$user_mobile' AND seat_type = 'vip' ");
    $row_secret_code = mysqli_fetch_array($request_secret_code);
    $secret_code = $row_secret_code['code'];
    
    if($user_secret_code == $secret_code){
        
        mysqli_query($con,"INSERT INTO booking (user_id,theater_id,status,current_status,event_id,qrcode,seat_type) VALUES ('$user_id','$user_theater_id','PENDING','PENDING','$user_event_id','$qrcode','vip')");
        //SUCCESS;
         $myObj->status = "Ok";
         $myObj->message = "suceess";
        
         echo json_encode($myObj);
         
        
    }
    else{
        // ERROR NOT ELIGIBLE FOR VIP;
         $myObj->status = "Failed";
         $myObj->message = "Error";
         echo json_encode($myObj);
    }
 }
 elseif(strcasecmp($seat_type,'mvp') == 0){
   
    $request_secret_code = mysqli_query($con,"SELECT code FROM secret_code where mobile = '$user_mobile' AND seat_type = 'mvp' ");
    $row_secret_code = mysqli_fetch_array($request_secret_code);
    $secret_code = $row_secret_code['code'];
    
    if($user_secret_code == $secret_code){
      
        
        mysqli_query($con,"INSERT INTO booking (user_id,theater_id,status,current_status,event_id,qrcode,seat_type) VALUES ('$user_id','$user_theater_id','PENDING','PENDING','$user_event_id','$qrcode','mvp')");
        
        //SUCCESS
         $myObj->status = "Ok";
         $myObj->message = "success";
         echo json_encode($myObj);
    }
    else{
        // ERROR NOT ELIGIBLE FOR VIP;
         $myObj->status = "Failed";
         $myObj->message = "Error";
         echo json_encode($myObj);
    }
 }
 else{
       // $str = $user_id.$user_theater_id.$user_event_id ;
       // $qrcode = sha1($str);
        $success=mysqli_query($con,"INSERT INTO booking (user_id,theater_id,status,current_status,event_id,qrcode,seat_type) VALUES ('$user_id','$user_theater_id','PENDING','PENDING','$user_event_id','$qrcode','normal')");
        if($success){
        //success
         $myObj->status = "Ok";
         $myObj->message = "success";
         echo json_encode($myObj);
        }else{
            $myObj->status = "Failed";
            $myObj->message = "error";
            echo json_encode($myObj);
        }
 }
}
else{
            $myObj->status = "Failed";
            $myObj->message = "you can book only 1 ticket";
            echo json_encode($myObj);
        }
?>