 <!-----------------------Include Files-------------------------->
<?php
    include('header.php');
    include('connection.php');
/*-------------------session Start-------------------*/ 
    @ob_start();
    @session_start();
    
/* ---------------------End of session--------------*/
?>


 
 <!--------------------------Horizontal Sub-navbar------------------------->
    <div class="breadcrumbs">
        <div class="breadcrumbs-inner">
            <div class="row m-0">
                <div class="col-sm-4">
                    <div class="page-header float-left">
                       
                    </div>
                </div>
                <div class="col-sm-8">
                    <div class="page-header float-right">
                        <div class="page-title">
                            <ol class="breadcrumb text-right">
                                <li><a href="#">Dashboard</a></li>
                                <li><a href="#">Events</a></li>
                                <li class="active">Create Seats</li>
                            </ol>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


<div class="content pb-0">
    <div class="row">
      
            <div class="col-lg-6">
                <div class="card">
                    <div class="card-header">Seat Allocation</div>
                        <div class="card-body card-block">
                            <form action="#" method="post" class="form-horizontal">
                                <div class="row form-group">
                                    <div class="col col-md-12">
                                	    <label for="company" class=" form-control-label">Theater Name</label> 
                                        <input type="text" name="tname" placeholder="Enter Theater Name" class="form-control"required>
                                    </div>
                                </div>
                                 <div class="row form-group">
                                    <div class="col col-md-12">
                                	    <label for="company" class=" form-control-label">Theater Capacity</label> 
                                        <input type="text" name="capacity" placeholder=" Enter Capacity of Theater" class="form-control"required>
                                    </div>
                                </div>
                                <div class="row form-group">
                                    <div class="col col-md-12">
                                	    <label for="company" class=" form-control-label">Address</label> 
                                        <input type="text" name="address" placeholder=" Enter Address in Only Url" class="form-control" required>
                                    </div>
                                </div>
                                <div class="row form-group">
                                    <div class="col col-md-12">
                                	    <label for="company" class=" form-control-label">Event Date</label> 
                                        <input type="date" name="date" placeholder=" Enter the Event Time" class="form-control"required>
                                    </div>
                                </div>
                                <div class="row form-group">
                                    <div class="col col-md-12">
                                	    <label for="company" class=" form-control-label">Event Time</label> 
                                        <input type="time" name="time" placeholder=" Enter The  Event Date" class="form-control"required>
                                    </div>
                                </div>
                                <div class="row form-group">
                                    <div class="col col-md-12">
                                	    <label for="company" class=" form-control-label">Event Screen</label> 
                                        <input type="text" name="screen" placeholder=" Enter The Screen No" class="form-control"required>
                                    </div>
                                </div>
                                <div class="row form-group">
                                    <div class="col col-md-12">
                                	    <label for="company" class=" form-control-label">VIP</label> 
                                        <input type="text" name="vip" placeholder="Enter VIP Seats" class="form-control" required>
                                    </div>
                                </div>
                                 <div class="row form-group">
                                    <div class="col col-md-12">
                                	    <label for="company" class=" form-control-label">MVP</label> 
                                        <input type="text" name="mvp" placeholder=" Enter MVP Seats" class="form-control" required>
                                    </div>
                                </div>
                                 <div class="row form-group">
                                    <div class="col col-md-12">
                                	    <label for="company" class=" form-control-label">Normal</label> 
                                        <input type="text" name="normal" placeholder=" Enter Normal Seats" class="form-control"required>
                                    </div>
                                </div>
                                    <center> <button type="submit"  name="submit" class="btn btn-danger" >Add</button></center>
                            </form>
                         </div>
                </div>
                
                </div>
            <div class="col-lg-6">
                  <div class="row">
                <div class="card">
                    <div class="card-header">Generate code</div>
                    <div class="card-body card-block">
                            <form action="process.php" method="post" class="form-horizontal">
                                    <div class="col col-md-12">
                                        <label>Select Category</label>
                                            <select class="form-control" name="type" value="<?php echo $type;?>" required>
                                                    <option value="<?php echo$type;?>"><?php echo $type;?></option>
                                                    <option value="vip">VIP</option>
                                                    <option value="mvp">MVP</option>
                                                   
                                            </select><br><br>
                                    </div>
                                    <div class="row form-group">
                                    <div class="col col-md-12">
                                	    <label for="company" class=" form-control-label">Mobile No</label> 
                                        <input type="text" name="mobile" placeholder="Enter mobile no" class="form-control">
                                    </div>
                                </div>
                               
                                   <center> <button type="submit"  name="send" class="btn btn-danger">Send</button></center>
                            </form>
                    </div>      
                </div>
            </div>
    </div>
</div>   <!-- .content -->
    
      <?php
       if(isset($_POST['submit'])) {
           
            include_once("db.php");

            $vip=$_POST['vip'];
            $mvp=$_POST['mvp'];
            $normal=$_POST['normal'];
            $tname=$_POST['tname'];
            $capacity=$_POST['capacity'];
            $address=$_POST['address'];
            $date=$_POST['date'];
             $time=$_POST['time'];
              $screen=$_POST['screen'];
               
            mysqli_query($db,"INSERT INTO theaters (name,capacity,event_date,event_time,screen_no,vip,mvp,normal) VALUES('$tname','$capacity','$date','$time','$screen','$vip','$mvp','$normal')");
            mysqli_query($db,"INSERT INTO address(map_adress) VALUES('$address')");
    
                $theater = mysqli_query($db,"SELECT id FROM theaters WHERE created_date = (SELECT MAX(created_date) FROM theaters)");
                $theater_row = mysqli_fetch_array($theater);
                $th_id = $theater_row['id'];
                echo $th_id ;
                
                $address = mysqli_query($db,"SELECT id FROM address WHERE created_at = (SELECT MAX(created_at) FROM address)");
                $address_row = mysqli_fetch_array($address);
                $ad_id = $address_row['id'];
                echo $ad_id ;
                
                mysqli_query($db,"update theaters set address_id = '$ad_id' WHERE id='$th_id'");
                
                
                
                
                
                
                 $event = mysqli_query($db,"select e.id as eid,t.id as tid from events e join theaters t on t.id=e.theater order by e.id desc limit 1");
                $event_row = mysqli_fetch_array($event);
                $event_id = $event_row['eid'];
                $theater_id = $event_row['tid'];
                var_dump($event_id);
                var_dump($theater_id);
                
                mysqli_query($db,"update theaters set event_id ='$event_id' WHERE id='$theater_id'");
               
               
            
       if(!$query1)
                                                           {
                                            echo "<script>alert('seat allocated Successfully........!');
                                            window.location='seat.php';
                                            </script>";
                                            } 
       
       }
       
     
       
        ?>
             
   
   <!---------------------------code for OTP--------------------------------------->       
                    



<div class="clearfix">&nbsp;</div>



  <!---------------------------------footer ------------------------------------>            
     
            <?php
                include('footer.php');
            ?>